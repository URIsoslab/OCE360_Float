#ifndef sci_sensor_H
#define sci_sensor_H
 
#include "mbed.h"
 
class LM19
{
 
public:
    LM19(PinName in1); //initialization function
    float c1, c2, c3, c4;
    float temp();//temp comp.
private:
    AnalogIn _in1;
 
};
 
class PhotoCell
{
 
public:
    PhotoCell(PinName in1);
    float Rs;
    float light();
 
private:
    AnalogIn _in1;
 
};
 
#endif